﻿# !/usr/bin/env python
# -*- coding:utf-8 -*- 
"""
======================
@Project:
@time:2019/10/20 0020:下午 3:29
@Author:ASJ
@email:Ai_shan_jiang@163.com
@File:
@Other:
======================
"""

import jieba  # 导入jieba中文分词包
import jieba.analyse
import os
from os import path


def get_text(filename: str, data: []):
    all_list = []
    with open(filename, "r", encoding='utf-8') as fp:
        str = fp.readlines()
    for str1 in str:
        all_list.append(str1)
    # str = str.lower()  # 数据清洗
    # for ch in ["~!@#$%^&*()_+{}|[]\\||:;'<>?,./"]:
    #     str = str.replace(ch, " ")  # 分词
    for ch in ['.txt']:
        file1 = filename.replace(ch, '')
    file_path = './需求获取\\' + file1
    if not os.path.exists('./需求获取'):
        os.mkdir('./需求获取')
    if not os.path.exists(file_path):
        os.mkdir(file_path)
    for word in data:
        file2 = file_path + '\\' + word + '.txt'
        for kk in all_list:
            if not kk.find(word) == -1:
                with open(file2, 'w+', encoding='utf-8') as xp:
                    xp.writelines([word, '\n', kk, '\n'])
    pass


if __name__ == '__main__':
    print('\t\t\t从高频关键词获取相应的需求')
    file = input("\n\n输入全部需求的文件（后缀【.txt】不用写）")
    if file.find('.txt') == -1:
        file = file + '.txt'
    sl_info = []
    inp = ""
    print('\n\n输入关键词或句子，支持输入多个，如果输入0，结束输入\n')
    while not inp == '0':
        inp = input()
        sl_info.append(inp)
        print('当前关键词:  ', sl_info)
    print('\n\n正在处理', file)
    sl_info.remove('0')
    get_text(file, sl_info)
    print('\n处理完毕，欢迎下次再来！\n')
    lets_end = input('\n请按任意键结束程序：')
