﻿# !/usr/bin/env python
# -*- coding:utf-8 -*- 
"""
======================
@Project:将我们的需求进行分类，比较其优先级
@time:2019/11/17 0017:下午 3:29
@Author:ASJ
@email:Ai_shan_jiang@163.com
@File:
@Other:
======================
"""
import jieba  # 导入jieba中文分词包
import jieba.analyse
import os
from os import path


def classify(filename: str, data: []):
    all_list = []
    with open(filename, "r", encoding='utf-8') as fp:
        str = fp.readlines()
    for str1 in str:
        all_list.append(str1)
    file_path = './需求分类'
    if not os.path.exists('./需求分类'):
        os.mkdir('./需求分类')
    if not os.path.exists(file_path):
        os.mkdir(file_path)
    for word in data:
        file2 = file_path + '\\' + word + '--出现统计' + '.txt'
        flg = 0
        for kk in all_list:
            if not kk.find(word) == -1:
                flg = flg + 1
                if flg == 1:
                    with open(file2, 'a+', encoding='utf-8') as xp:
                        xp.writelines(['需求关键词：', word, '\n', '所在标签：', filename, '\n所在句子：', kk, '\n'])
                else:
                    with open(file2, 'a+', encoding='utf-8') as xxp:
                        xxp.writelines(['\n：', kk, '\n'])
    pass


def how_many_files(inpu: []):
    biaoqian = ['candidate 候选人', 'editor-core 编辑核心', 'file-encoding 文件编码', 'freeze-slow-crash 冻结慢速崩溃',
                'important 重要', 'invalid 无效', 'iteration-plan 迭代计划', 'perf 性能', 'plan-item 计划项目',
                'search 搜索', 'smoke-test 冒烟测试']
    for ii in biaoqian:
        file_what = '所有标签\\' + ii + '.txt'
        classify(file_what, inpu)
    for w in inpu:
        file4 = './需求分类' + '\\' + w + '--出现统计' + '.txt'
        all_list2 = []
        with open(file4, "r", encoding='utf-8') as fpp:
            str2 = fpp.readlines()
        for str1 in str2:
            all_list2.append(str1)
        file3 = './需求分类' + '\\' + w + '--所在标签' + '.txt'
        flg2 = 0
        for i3 in biaoqian:
            flg3 = 0
            for kk in all_list2:
                if not kk.find(i3) == -1:
                    flg2 = flg2 + 1
                    flg3 = flg3 + 1
                    if flg2 == 1:
                        with open(file3, 'w+', encoding='utf-8') as xpp:
                            xpp.writelines(['需求关键词：', w, '\n', '--所在标签：', i3, '\n'])
                    else:
                        if flg3 == 1:
                            with open(file3, 'a+', encoding='utf-8') as rr:
                                rr.writelines(['需求关键词：', w, '\n', '--所在标签：', i3, '\n'])
    pass


if __name__ == '__main__':
    print('\t\t\t将获取到的需求按我们的标签进行分类，')
    # file = input("\n\n输入全部需求的文件（后缀【.txt】不用写）")
    # if file.find('.txt') == -1:
    #     file = file + '.txt'
    sl_info = []
    inp = ""
    print('\n\n输入关键词或句子，支持输入多个，如果输入0，结束输入\n')
    while not inp == '0':
        inp = input()
        sl_info.append(inp)
        print('当前关键词:  ', sl_info)
    print('\n请耐心等待...\n')
    sl_info.remove('0')
    how_many_files(sl_info)
    print('\n欢迎下次再来！\n')
    lets_end = input('\n请按任意键结束程序：')




